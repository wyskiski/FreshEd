<?php
/**
 * Plugin Name: Miresa
 * Plugin URI: https://codecanyon.net/user/egemenerd/portfolio
 * Description: WordPress Rich Text Editor For BuddyPress
 * Version: 1.0.3
 * Author: ThemeMasters
 * Author URI: http://codecanyon.net/user/egemenerd
 * License: http://codecanyon.net/licenses
 * Text Domain: miresa
 * Domain Path: /languages/
 *
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'MIRESA_PLUGIN_URL' ) ) {
	define( 'MIRESA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/* ---------------------------------------------------------
Custom Metaboxes - github.com/WebDevStudios/CMB2
----------------------------------------------------------- */

// Check for PHP version
$miresadir = ( version_compare( PHP_VERSION, '5.3.0' ) >= 0 ) ? __DIR__ : dirname( __FILE__ );

if ( file_exists(  $miresadir . '/cmb2/init.php' ) ) {
    require_once($miresadir . '/cmb2/init.php');
} elseif ( file_exists(  $miresadir . '/CMB2/init.php' ) ) {
    require_once($miresadir . '/CMB2/init.php');
}

/* ---------------------------------------------------------
Include required files
----------------------------------------------------------- */

function miresa_buddypress() {
    include_once('settings.php');
    include_once('mainClass.php');
}
add_action( 'bp_include', 'miresa_buddypress' );