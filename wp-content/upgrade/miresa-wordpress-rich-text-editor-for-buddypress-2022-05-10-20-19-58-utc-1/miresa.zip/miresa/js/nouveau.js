(function($) {
    "use strict";

    /* Modules */
    var modules = $.parseJSON(miresaParams.modules);
    var selectedModules = [];

    if (modules.length !== 0) {
        $.each(modules, function( index, val ) {
            if (val == 'fontname') {
                selectedModules.push(['fontname', ['fontname','fontsize', 'fontsizeunit']]);
            } else if (val == 'list') {
                selectedModules.push(['list',['ul', 'ol']]);
            } else if (val == 'misc') {
                selectedModules.push(['misc',['undo', 'redo']]);
            } else if (val == 'giphy') {
                selectedModules.push(['giphy',['giphy', 'giphyStickers']]);
            } else {
                selectedModules.push([val, [val]]);
            }
        });
    }

    /* Variables */
    var fontSizes = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '12', '14', '16', '18', '20', '22', '24', '26', '28', '30', '32', '34', '36', '38', '40', '42', '44', '46', '48', '50'];
    var fontNames = ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Helvetica Neue', 'Helvetica', 'Impact', 'Lucida Grande', 'Tahoma', 'Times New Roman', 'Verdana'];
    var fontSizeUnits = ['px', 'pt', 'rem'];
    var lineHeights = ['0.1', '0.2', '0.3', '0.4', '0.5', '1.0', '1.1', '1.2', '1.3', '1.4', '1.5', '1.6', '1.7', '1.8', '1.9', '2.0', '2.5', '3.0', '3.5', '4.0', '4.5', '5.0'];
    var toolbar = selectedModules;
    var popover = {
        image: [
            ['image', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
            ['float', ['floatLeft', 'floatRight', 'floatNone']],
            ['remove', ['imageTitle','removeMedia']]
        ],
    };
    var lang = miresaParams.lang.replace("_", "-");
    var height = miresaParams.editorheight;
    var placeholder = miresaParams.placeholder;

    /* Image Compression */
    $.summernote.options.imageCompression = {
        enabled: true,
        maxSizeMB: parseFloat(miresaParams.maximgsize),
        maxWidthOrHeight: parseInt(miresaParams.maxwidth)
    };

    /* Whats New */
    $(document).ready(function() {
        $('body').find('#whats-new').summernote({
            height: height,
            minHeight: null,
            maxHeight: null,
            lang: lang,
            fontNames: fontNames,
            lineHeights: lineHeights,
            imageTitle: {
                specificAltField: true,
            },
            dialogsInBody: true,
            dialogsFade: true,
            popover: popover,
            fontSizes: fontSizes,
            fontSizeUnits: fontSizeUnits,
            toolbar:toolbar,
            placeholder: placeholder,
            callbacks: {
                onFocus: function() {
                    $('body').find("#whats-new").trigger('focusin');
                }
            },
        });

    });

    /* Reset After Submit */
    $(document).ajaxComplete(function( event, request, settings ) {
        var str = 'action=post_update';
        var str2 = 'action=new_activity_comment';
        var str3 = 'action=youzify_post_update';
        if(typeof settings.data !== "undefined") {
            if(settings.data.indexOf(str) != -1 || settings.data.indexOf(str2) != -1 || settings.data.indexOf(str3) != -1){
                $('body').find('.note-editable').html('');
                $('body').find('.note-codable').html('');
            }
        }
    });

    /* Reset After Cancel */
    $('body').on('click','#aw-whats-new-reset',function(){
        $('body').find('.note-editable').html('');
        $('body').find('.note-codable').html('');
    });

    $('body').on('click','.ac-reply-cancel',function(){
        $('body').find('.note-editable').html('');
        $('body').find('.note-codable').html('');
    });

    /* Comments */
    $('body').on('click','.activity-content .acomment-reply',function(){
        var id = $(this).attr('id');
        var inputID = id.replace("acomment-comment", "ac-input");
        $('body').find('#' + inputID).summernote({
            height: height,
            minHeight: null,
            maxHeight: null,
            lang: lang,
            fontNames: fontNames,
            lineHeights: lineHeights,
            imageTitle: {
                specificAltField: true,
            },
            popover: popover,
            fontSizes: fontSizes,
            fontSizeUnits: fontSizeUnits,
            toolbar:toolbar,
            placeholder: placeholder
        });
    });

    /* Replies */
    $('body').on('click','.activity-comments .acomment-reply',function(){
        var id = $(this).attr('id');   
        var inputID = id.split('reply-').pop().split('-')[0];
        $('body').find('#ac-input-' + inputID).summernote({
            height: height,
            minHeight: null,
            maxHeight: null,
            lang: lang,
            fontNames: fontNames,
            lineHeights: lineHeights,
            imageTitle: {
                specificAltField: true,
            },
            popover: popover,
            fontSizes: fontSizes,
            fontSizeUnits: fontSizeUnits,
            toolbar:toolbar,
            placeholder: placeholder
        });
    });

    /* Responsive Dropdown */
    $(window).on('load resize orientationchange', function () {
        $('body').find('.note-dropdown-menu').each(function() {
            var ww = document.body.clientWidth;
            var offsetLeft = $(this).parent().offset().left;
            var screen = offsetLeft + $(this).width();
            if (miresaParams.rtl == 'no') {
                if(screen >= ww) {
                    $(this).css('left', 'auto');
                    $(this).css('right', '0');
                } else {
                    $(this).css('left', '0');
                    $(this).css('right', 'auto');
                }
            } else {
                if(screen >= ww) {
                    $(this).css('right', 'auto');
                    $(this).css('left', '0');
                } else {
                    $(this).css('right', '0');
                    $(this).css('left', 'auto');
                }
            }
        });
    });

})(jQuery);