<?php
defined( 'ABSPATH' ) || exit;

class Miresa {
    /**
	 * The single instance of the class
	 */
	protected static $_instance = null;

    /**
	 * Main Instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /**
	 * Miresa Constructor
	 */
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        add_action('bp_enqueue_scripts', array($this, 'scripts'));
        add_action('wp_ajax_miresaGiphyTrending', array($this, 'gif_trending'));
        add_action('wp_ajax_miresaGiphySearch', array($this, 'gif_search'));
        add_action('wp_ajax_miresaGiphyStickersTrending', array($this, 'sticker_trending'));
        add_action('wp_ajax_miresaGiphyStickersSearch', array($this, 'sticker_search'));
        add_filter('bp_activity_allowed_tags', array($this, 'allowed_html'));
        add_filter('safecss_filter_attr_allow_css', array($this, 'allow_rgb'));
        add_filter('kses_allowed_protocols', array($this, 'protocols'));
    }

    /* Admin Scripts */
    public function admin_scripts($hook){
        if ('toplevel_page_miresa' == $hook) {
            wp_enqueue_style('miresa-admin', MIRESA_PLUGIN_URL . 'css/admin.css', false, '1.0');
            wp_enqueue_script('miresa-admin', MIRESA_PLUGIN_URL . 'js/admin.js', array( 'jquery' ), '1.0', true);
        } else {
            return;
        }
    }

    /* Scripts */
    public function scripts($hook){
        $suffix = ( defined( 'MIRESA_SCRIPT_DEBUG' ) && MIRESA_SCRIPT_DEBUG ) ? '' : '.min';
        $locale = get_locale();
        $templatePack = '';

        if (get_theme_support('buddypress-use-nouveau')) {
            $templatePack = 'nouveau';
        } else if (get_theme_support('buddypress-use-legacy')) {
            $templatePack = 'legacy';
        } else {
            $templatePack = bp_get_theme_package_id('nouveau');
        }

        $supportedLanguges = array('ar_AR', 'az_AZ', 'bg_BG', 'ca_ES', 'cs_CZ', 'da_DK', 'de_DE', 'el_GR', 'es_ES', 'es_EU', 'fa_IR', 'fi_FI', 'fr_FR', 'gl_ES', 'he_IL', 'hr_HR', 'hu_HU', 'id_ID', 'it_IT', 'ja_JP', 'ko_KR', 'lt_LT', 'lt_LV', 'mn_MN', 'nb_NO', 'nl_NL', 'pl_PL', 'pt_BR', 'pt_PT', 'ro_RO', 'ru_RU', 'sk_SK', 'sl_SI', 'sr_RS', 'sv_SE', 'ta_IN', 'th_TH', 'tr_TR', 'uk_UA', 'uz_UZ', 'vi_VN', 'zh_CN', 'zh_TW');
        $modules = MiresaSettings::get_option('modules', array('style','bold','italic','underline','strikethrough','superscript','subscript','fontname','height','forecolor','backcolor','paragraph','emoji','specialchars','list','hr','link','picture','video','table','clear','misc','codeview','help'));
        $placeholder = MiresaSettings::get_option('placeholder', '');
        $max_img_size = MiresaSettings::get_option('max_img_size', 2000);
        $max_img_width = MiresaSettings::get_option('max_img_width', 600);
        $editor_height = MiresaSettings::get_option('editor_height', 200);
        $pagination =  MiresaSettings::get_option('giphy_pagination', 10);
        $rtl = 'no';

        wp_enqueue_style('summernote-lite', MIRESA_PLUGIN_URL . 'css/summernote-lite'. $suffix .'.css', false, '1.0');
        wp_enqueue_style('miresa', MIRESA_PLUGIN_URL . 'css/style.css', false, '1.0');

        if (is_rtl()) {
            $rtl = 'yes';
            wp_enqueue_style('miresa-rtl', MIRESA_PLUGIN_URL . 'css/rtl.css', false, '1.0');
        }

        wp_enqueue_script('summernote-lite', MIRESA_PLUGIN_URL . 'js/summernote-lite.min.js', array( 'jquery' ), '1.0', true);

        if (in_array("emoji", $modules)) {
            wp_enqueue_script('summernote-emoji', MIRESA_PLUGIN_URL . 'plugins/emoji/script'. $suffix .'.js', array( 'jquery', 'summernote-lite' ), '1.0', true);
        }

        if (in_array("specialchars", $modules)) {
            wp_enqueue_script('summernote-specialchars', MIRESA_PLUGIN_URL . 'plugins/specialchars/script'. $suffix .'.js', array( 'jquery', 'summernote-lite' ), '1.0', true);
        }

        if (in_array("picture", $modules)) {
            wp_enqueue_script('summernote-image-title', MIRESA_PLUGIN_URL . 'plugins/image-title/script'. $suffix .'.js', array( 'jquery', 'summernote-lite' ), '1.0', true);
            wp_enqueue_script('summernote-browser-compress', MIRESA_PLUGIN_URL . 'plugins/image-compress/browser.min.js', array( 'jquery', 'summernote-lite' ), '1.0', true);
            wp_enqueue_script('summernote-image-compress', MIRESA_PLUGIN_URL . 'plugins/image-compress/script'. $suffix .'.js', array( 'jquery', 'summernote-lite' ), '1.0', true);
        }

        if (in_array("giphy", $modules)) {
            wp_enqueue_script('summernote-giphy', MIRESA_PLUGIN_URL . 'plugins/giphy/script'. $suffix .'.js', array( 'jquery', 'summernote-lite' ), '1.0', true);
        }

        if (in_array($locale, $supportedLanguges)) {
            wp_enqueue_script('summernote-' . $locale, MIRESA_PLUGIN_URL . 'js/lang/summernote_' . $locale . '.js', array( 'jquery', 'summernote-lite' ), '1.0', true);
        }
        
        wp_enqueue_script('miresa', MIRESA_PLUGIN_URL . 'js/' . $templatePack . $suffix .'.js', array( 'jquery', 'summernote-lite' ), '1.0', true);


        wp_localize_script(
            'miresa',
            'miresaParams',
            [
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce('miresa-nonce'),
                'lang' => $locale,
                'placeholder' => $placeholder,
                'editorheight' => $editor_height,
                'maximgsize' => $max_img_size,
                'maxwidth' => $max_img_width,
                'limit' => $pagination,
                'modules' => json_encode($modules),
                'wrong' => esc_html__( 'Something went wrong.', 'miresa' ),
                'gif' => esc_html__( 'GIF', 'miresa' ),
                'sticker' => esc_html__( 'STICKER', 'miresa' ),
                'insertgif' => esc_html__( 'Insert GIF', 'miresa' ),
                'insertsticker' => esc_html__( 'Insert Sticker', 'miresa' ),
                'rtl' => $rtl
            ]
        );
    }

    /* Trending GIFs */
    public function gif_trending() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'miresa-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'miresa'));
        }
        // Get The Api Key
        $getApiKey =  MiresaSettings::get_option('giphy_api_key', '');

        if (empty($getApiKey)) {
            echo '<div class="miresa-msg danger">' . esc_html__( 'API key is required.', 'miresa' ) . '</div>';
        } else {
            $apiKey = trim($getApiKey);
            $error = '';
            $limit =  MiresaSettings::get_option('giphy_pagination', 10);
            $caching =  MiresaSettings::get_option('giphy_caching', 24);
            $rating =  MiresaSettings::get_option('giphy_rating', 'g');
            $curlURL = "https://api.giphy.com/v1/gifs/trending?api_key=" . $apiKey . "&offset=0&limit=" . $limit . "&rating=" . $rating;
            $transient_value = get_transient($curlURL);
            $giphyLogo = MIRESA_PLUGIN_URL . 'assets/giphy-logo.png';

            if (false !== $transient_value){
                $response =	get_transient($curlURL);
                $data = json_decode($response);
            } else {
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $curlURL,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 20,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer {$apiKey}"
                    )
                ));
            
                $response = curl_exec($ch);
                $data = json_decode($response);
                if (curl_errno($ch) > 0) { 
                    $error = esc_html__( 'Error connecting to API: ', 'miresa' ) . curl_error($ch);
                }

                $meta = $data->meta;
                $status = $meta->status;
                $msg = $meta->msg;

                if ($status !== 200) {
                    $error = 'HTTP ' . $status . ' - ' . $msg;
                }

                if (empty($error)) {
                    set_transient( $curlURL, $response,$caching * HOUR_IN_SECONDS );
                }
            }

            
            if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                $error = esc_html__( 'Error parsing response', 'miresa' );
            }

            if (!empty($error)) {
                echo '<div class="miresa-msg danger">' . $error . '</div>';
            } else {
                $gifs = $data->data;
                echo '<div class="miresa-search-box"><input type="search" class="note-form-control note-input" placeholder="' . esc_html__('Enter Keyword...', 'miresa') . '" autocomplete="off" data-keyword="" /><button type="button" class="note-btn note-btn-primary"><span class="dashicons dashicons-search"></span></button></div>';

                echo '<div class="miresa-grid">';
                foreach ( $gifs as $gif ) {
                    $url = $gif->url;
                    $title = $gif->title;
                    $images = $gif->images;
                    $img = $images->original->url;
                    $src = $images->fixed_width->url;
                    echo '<div class="miresa-grid-item">';
                    echo '<a href="' . esc_url($url) . '" target="_blank" class="miresa-gif-info"><span class="dashicons dashicons-info"></span></a>';
                    echo '<img class="lazy" src="' . esc_url($src) . '" title="' . esc_attr($title) . '"  data-img="' . esc_url($img) . '" data-title="' . esc_attr($title) . '" />';
                    echo '</div>';
                }
                echo '</div>';

                echo '<div class="miresa-loadmore"><button type="button" class="note-btn note-btn-primary" autocomplete="off">' . esc_html__('Load More', 'miresa') . '</button></div>';
                echo '<div class="miresa-credit"><a href="https://giphy.com/" target="_blank"><img src="' . esc_url($giphyLogo) . '" /></a></div>';
            }
        }
        wp_die();
    }

    /* Search GIFs */
    public function gif_search() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'miresa-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'miresa'));
        }

        // Get The Api Key
        $getApiKey =  MiresaSettings::get_option('giphy_api_key', '');

        if (empty($getApiKey)) {
            echo '<div class="miresa-msg danger">' . esc_html__( 'API key is required.', 'miresa' ) . '</div>';
        } else {
            $keyword = sanitize_text_field($_POST['keyword']);
            $apiKey = trim($getApiKey);
            $error = '';
            $limit =  MiresaSettings::get_option('giphy_pagination', 10);
            $caching =  MiresaSettings::get_option('giphy_caching', 24);
            $lang =  MiresaSettings::get_option('giphy_lang', 'en');
            $rating =  MiresaSettings::get_option('giphy_rating', 'g');
            $offset = sanitize_text_field($_POST['offset']);
            $loadmore = sanitize_text_field($_POST['loadmore']);
            $giphyLogo = MIRESA_PLUGIN_URL . 'assets/giphy-logo.png';

            if (empty($keyword)) {
                $curlURL = "https://api.giphy.com/v1/gifs/trending?api_key=" . $apiKey . "&offset=" . $offset . "&limit=" . $limit . "&rating=" . $rating;
            } else {
                $curlURL = "https://api.giphy.com/v1/gifs/search?api_key=" . $apiKey . "&q=" . $keyword . "&offset=" . $offset . "&limit=" . $limit . "&rating=" . $rating . "&lang=" . $lang;
            }
            
            $transient_value = get_transient($curlURL);

            if (false !== $transient_value){
                $response =	get_transient($curlURL);
                $data = json_decode($response);
            } else {
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $curlURL,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 20,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer {$apiKey}"
                    )
                ));
            
                $response = curl_exec($ch);
                $data = json_decode($response);
                if (curl_errno($ch) > 0) { 
                    $error = esc_html__( 'Error connecting to API: ', 'miresa' ) . curl_error($ch);
                }

                $meta = $data->meta;
                $status = $meta->status;
                $msg = $meta->msg;

                if ($status !== 200) {
                    $error = 'HTTP ' . $status . ' - ' . $msg;
                }

                if (empty($error)) {
                    set_transient( $curlURL, $response,$caching * HOUR_IN_SECONDS );
                }
            }
            
            if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                $error = esc_html__( 'Error parsing response', 'miresa' );
            }

            if (!empty($error)) {
                echo '<div class="miresa-msg danger">' . $error . '</div>';
            } else {
                $gifs = $data->data;

                if ($loadmore == 'no') {
                    echo '<div class="miresa-search-box"><input type="search" class="note-form-control note-input" placeholder="' . esc_html__('Enter Keyword...', 'miresa') . '" autocomplete="off" value="' . esc_attr($keyword) . '" data-keyword="' . esc_attr($keyword) . '" /><button type="button" class="note-btn note-btn-primary"><span class="dashicons dashicons-search"></span></button></div>';

                    echo '<div class="miresa-grid">';
                }
                foreach ( $gifs as $gif ) {
                    $url = $gif->url;
                    $title = $gif->title;
                    $images = $gif->images;
                    $img = $images->original->url;
                    $src = $images->fixed_width->url;
                    echo '<div class="miresa-grid-item">';
                    echo '<a href="' . esc_url($url) . '" target="_blank" class="miresa-gif-info"><span class="dashicons dashicons-info"></span></a>';
                    echo '<img class="lazy" src="' . esc_url($src) . '" title="' . esc_attr($title) . '"  data-img="' . esc_url($img) . '" data-title="' . esc_attr($title) . '" />';
                    echo '</div>';
                }
                if ($loadmore == 'no') {
                    echo '</div>';
                    echo '<div class="miresa-loadmore"><button type="button" class="note-btn note-btn-primary" autocomplete="off">' . esc_html__('Load More', 'miresa') . '</button></div>';
                    echo '<div class="miresa-credit"><a href="https://giphy.com/" target="_blank"><img src="' . esc_url($giphyLogo) . '" /></a></div>';
                }
            }
        }
        wp_die();
    }

    /* Trending GIFs */
    public function sticker_trending() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'miresa-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'miresa'));
        }
        // Get The Api Key
        $getApiKey =  MiresaSettings::get_option('giphy_api_key', '');

        if (empty($getApiKey)) {
            echo '<div class="miresa-msg danger">' . esc_html__( 'API key is required.', 'miresa' ) . '</div>';
        } else {
            $apiKey = trim($getApiKey);
            $error = '';
            $limit =  MiresaSettings::get_option('giphy_pagination', 10);
            $caching =  MiresaSettings::get_option('giphy_caching', 24);
            $rating =  MiresaSettings::get_option('giphy_rating', 'g');
            $curlURL = "https://api.giphy.com/v1/stickers/trending?api_key=" . $apiKey . "&offset=0&limit=" . $limit . "&rating=" . $rating;
            $transient_value = get_transient($curlURL);
            $giphyLogo = MIRESA_PLUGIN_URL . 'assets/giphy-logo.png';

            if (false !== $transient_value){
                $response =	get_transient($curlURL);
                $data = json_decode($response);
            } else {
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $curlURL,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 20,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer {$apiKey}"
                    )
                ));
            
                $response = curl_exec($ch);
                $data = json_decode($response);
                if (curl_errno($ch) > 0) { 
                    $error = esc_html__( 'Error connecting to API: ', 'miresa' ) . curl_error($ch);
                }

                $meta = $data->meta;
                $status = $meta->status;
                $msg = $meta->msg;

                if ($status !== 200) {
                    $error = 'HTTP ' . $status . ' - ' . $msg;
                }

                if (empty($error)) {
                    set_transient( $curlURL, $response,$caching * HOUR_IN_SECONDS );
                }
            }

            
            if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                $error = esc_html__( 'Error parsing response', 'miresa' );
            }

            if (!empty($error)) {
                echo '<div class="miresa-msg danger">' . $error . '</div>';
            } else {
                $gifs = $data->data;
                echo '<div class="miresa-search-box"><input type="search" class="note-form-control note-input" placeholder="' . esc_html__('Enter Keyword...', 'miresa') . '" autocomplete="off" data-keyword="" /><button type="button" class="note-btn note-btn-primary"><span class="dashicons dashicons-search"></span></button></div>';

                echo '<div class="miresa-grid">';
                foreach ( $gifs as $gif ) {
                    $url = $gif->url;
                    $title = $gif->title;
                    $images = $gif->images;
                    $img = $images->original->url;
                    $src = $images->fixed_width->url;
                    echo '<div class="miresa-grid-item">';
                    echo '<a href="' . esc_url($url) . '" target="_blank" class="miresa-gif-info"><span class="dashicons dashicons-info"></span></a>';
                    echo '<img class="lazy" src="' . esc_url($src) . '" title="' . esc_attr($title) . '"  data-img="' . esc_url($img) . '" data-title="' . esc_attr($title) . '" />';
                    echo '</div>';
                }
                echo '</div>';

                echo '<div class="miresa-loadmore"><button type="button" class="note-btn note-btn-primary" autocomplete="off">' . esc_html__('Load More', 'miresa') . '</button></div>';
                echo '<div class="miresa-credit"><a href="https://giphy.com/" target="_blank"><img src="' . esc_url($giphyLogo) . '" /></a></div>';
            }
        }
        wp_die();
    }

    /* Search GIFs */
    public function sticker_search() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'miresa-nonce' ) ) {
            wp_die(esc_html__('Security Error!', 'miresa'));
        }

        // Get The Api Key
        $getApiKey =  MiresaSettings::get_option('giphy_api_key', '');

        if (empty($getApiKey)) {
            echo '<div class="miresa-msg danger">' . esc_html__( 'API key is required.', 'miresa' ) . '</div>';
        } else {
            $keyword = sanitize_text_field($_POST['keyword']);
            $apiKey = trim($getApiKey);
            $error = '';
            $limit =  MiresaSettings::get_option('giphy_pagination', 10);
            $caching =  MiresaSettings::get_option('giphy_caching', 24);
            $lang =  MiresaSettings::get_option('giphy_lang', 'en');
            $rating =  MiresaSettings::get_option('giphy_rating', 'g');
            $offset = sanitize_text_field($_POST['offset']);
            $loadmore = sanitize_text_field($_POST['loadmore']);
            $giphyLogo = MIRESA_PLUGIN_URL . 'assets/giphy-logo.png';

            if (empty($keyword)) {
                $curlURL = "https://api.giphy.com/v1/stickers/trending?api_key=" . $apiKey . "&offset=" . $offset . "&limit=" . $limit . "&rating=" . $rating;
            } else {
                $curlURL = "https://api.giphy.com/v1/stickers/search?api_key=" . $apiKey . "&q=" . $keyword . "&offset=" . $offset . "&limit=" . $limit . "&rating=" . $rating . "&lang=" . $lang;
            }
            
            $transient_value = get_transient($curlURL);

            if (false !== $transient_value){
                $response =	get_transient($curlURL);
                $data = json_decode($response);
            } else {
                $ch = curl_init();
                curl_setopt_array($ch, array(
                    CURLOPT_URL => $curlURL,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 20,
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer {$apiKey}"
                    )
                ));
            
                $response = curl_exec($ch);
                $data = json_decode($response);
                if (curl_errno($ch) > 0) { 
                    $error = esc_html__( 'Error connecting to API: ', 'miresa' ) . curl_error($ch);
                }

                $meta = $data->meta;
                $status = $meta->status;
                $msg = $meta->msg;

                if ($status !== 200) {
                    $error = 'HTTP ' . $status . ' - ' . $msg;
                }

                if (empty($error)) {
                    set_transient( $curlURL, $response,$caching * HOUR_IN_SECONDS );
                }
            }
            
            if ($data === false && json_last_error() !== JSON_ERROR_NONE) {
                $error = esc_html__( 'Error parsing response', 'miresa' );
            }

            if (!empty($error)) {
                echo '<div class="miresa-msg danger">' . $error . '</div>';
            } else {
                $gifs = $data->data;

                if ($loadmore == 'no') {
                    echo '<div class="miresa-search-box"><input type="search" class="note-form-control note-input" placeholder="' . esc_html__('Enter Keyword...', 'miresa') . '" autocomplete="off" value="' . esc_attr($keyword) . '" data-keyword="' . esc_attr($keyword) . '" /><button type="button" class="note-btn note-btn-primary"><span class="dashicons dashicons-search"></span></button></div>';

                    echo '<div class="miresa-grid">';
                }
                foreach ( $gifs as $gif ) {
                    $url = $gif->url;
                    $title = $gif->title;
                    $images = $gif->images;
                    $img = $images->original->url;
                    $src = $images->fixed_width->url;
                    echo '<div class="miresa-grid-item">';
                    echo '<a href="' . esc_url($url) . '" target="_blank" class="miresa-gif-info"><span class="dashicons dashicons-info"></span></a>';
                    echo '<img class="lazy" src="' . esc_url($src) . '" title="' . esc_attr($title) . '"  data-img="' . esc_url($img) . '" data-title="' . esc_attr($title) . '" />';
                    echo '</div>';
                }
                if ($loadmore == 'no') {
                    echo '</div>';
                    echo '<div class="miresa-loadmore"><button type="button" class="note-btn note-btn-primary" autocomplete="off">' . esc_html__('Load More', 'miresa') . '</button></div>';
                    echo '<div class="miresa-credit"><a href="https://giphy.com/" target="_blank"><img src="' . esc_url($giphyLogo) . '" /></a></div>';
                }
            }
        }
        wp_die();
    }

    /* Allowed html tags required for the rich text editor */
    public function allowed_html() {
        return array(
            'a' => array(
                'href' => array(),
                'title' => array(),
                'target' => array(),
                'style' => array(),
                'class' => array()
            ),
            'font' => array(
                'color' => array()
            ),
            'span' => array(
                'style' => array(),
                'class' => array()
            ),
            'h1' => array(
                'style' => array(),
                'class' => array()
            ),
            'h2' => array(
                'style' => array(),
                'class' => array()
            ),
            'h3' => array(
                'style' => array(),
                'class' => array()
            ),
            'h4' => array(
                'style' => array(),
                'class' => array()
            ),
            'h5' => array(
                'style' => array(),
                'class' => array()
            ),
            'h6' => array(
                'style' => array(),
                'class' => array()
            ),
            'p' => array(
                'style' => array(),
                'class' => array(),
                'align' => array()
            ),
            'ul' => array(
                'style' => array(),
                'class' => array()
            ),
            'ol' => array(
                'style' => array(),
                'class' => array()
            ),
            'li' => array(
                'style' => array(),
                'class' => array()
            ),
            'table' => array(
                'class' => array(),
                'style' => array()
            ),
            'tbody' => array(
                'style' => array()
            ),
            'tfoot' => array(
                'style' => array()
            ),
            'thead' => array(
                'style' => array()
            ),
            'caption' => array(
                'style' => array()
            ),
            'tr' => array(
                'style' => array()
            ),
            'td' => array(
                'style' => array()
            ),
            'th' => array(
                'style' => array()
            ),
            'blockquote' => array(
                'style' => array(),
                'class' => array()
            ),
            'pre' => array(
                'style' => array(),
                'class' => array()
            ),
            'code' => array(
                'style' => array(),
                'class' => array()
            ),
            'br' => array(),
            'b' => array(
                'style' => array(),
                'class' => array()
            ),
            'u' => array(
                'style' => array(),
                'class' => array()
            ),
            'em' => array(
                'style' => array(),
                'class' => array()
            ),
            'strong' => array(
                'style' => array(),
                'class' => array()
            ),
            'hr' => array(
                'style' => array(),
                'class' => array()
            ),
            'i' => array(
                'style' => array(),
                'class' => array()
            ),
            'sub' => array(),
            'sup' => array(),
            'strike' => array(),
            'img' => array(
                'title' => array(),
                'src'   => array(),
                'class' => array(),
                'alt'   => array(),
                'style' => array()
            ),
            'iframe' => array(
                'src' => array(),
                'class' => array(),
                'width' => array(),
                'height' => array(),
                'frameborder' => array(),
            ),
        );
    }

    /* Required for rgb colors */
    public function allow_rgb() {
        return true;
    }

    /* Required for base64 image uploads */
    public function protocols($protocols) {
        $protocols[] = 'data';
        return $protocols;
    }
    
}

/**
 * Returns the main instance of the class
 */
function Miresa() {  
	return Miresa::instance();
}
// Global for backwards compatibility
$GLOBALS['Miresa'] = Miresa();