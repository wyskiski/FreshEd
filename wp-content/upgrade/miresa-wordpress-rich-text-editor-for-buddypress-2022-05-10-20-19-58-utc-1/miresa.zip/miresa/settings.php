<?php
defined( 'ABSPATH' ) || exit;

class MiresaSettings {
    /* The single instance of the class */
	protected static $_instance = null;

    /* Main Instance */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    /* Constructor */
    public function __construct() {
        add_action( 'cmb2_admin_init', array($this, 'register_metabox') );
        add_action( 'admin_enqueue_scripts',array($this, 'colorpicker_labels'), 99 );
        add_action( 'admin_enqueue_scripts', array($this, 'admin_scripts') );
    }

    /* Admin Scripts */
    public function admin_scripts($hook){
        if ('toplevel_page_miresa_options' == $hook)  {
            wp_enqueue_style('miresa-admin', MIRESA_PLUGIN_URL . 'css/admin.css', false, '1.0');
            wp_enqueue_script('miresa-admin', MIRESA_PLUGIN_URL . 'js/admin.js', array( 'jquery' ), '1.0', true); 
        } else {
            return;
        }
    }

    /**
    * Hook in and register a metabox to handle a plugin options page and adds a menu item.
    */
    public function register_metabox() {
        // TAB
        $args = array(
            'id'           => 'miresa_options',
            'title'        => esc_html__('Miresa Settings', 'miresa'),
            'menu_title'        => esc_html__('Miresa', 'miresa'),
            'object_types' => array( 'options-page' ),
            'option_key'   => 'miresa_options',
            'capability'      => 'manage_options',
            'menu_order'      => 1,
            'save_button'     => esc_html__( 'Save Settings', 'miresa' )
        );

        $options = new_cmb2_box( $args );

        $options->add_field( array(
            'name' => esc_html__( 'Modules', 'miresa' ),
            'id'   => 'modules',
            'type' => 'multicheck_inline',
            'options' => array(
                'style' => esc_html__( 'Style', 'miresa' ),
                'bold' => esc_html__( 'Bold', 'miresa' ),
                'italic' => esc_html__( 'Italic', 'miresa' ),
                'underline' => esc_html__( 'Underline', 'miresa' ),
                'strikethrough' => esc_html__( 'Strikethrough', 'miresa' ),
                'superscript' => esc_html__( 'Superscript', 'miresa' ),
                'subscript' => esc_html__( 'Subscript', 'miresa' ),
                'fontname' => esc_html__( 'Font', 'miresa' ),
                'height' => esc_html__( 'Line Height', 'miresa' ),
                'forecolor' => esc_html__( 'Text Color', 'miresa' ),
                'backcolor' => esc_html__( 'Background', 'miresa' ),
                'paragraph' => esc_html__( 'Paragraph', 'miresa' ),
                'emoji' => esc_html__( 'Emojis', 'miresa' ),
                'specialchars' => esc_html__( 'Specialchars', 'miresa' ),
                'list' => esc_html__( 'List', 'miresa' ),
                'hr' => esc_html__( 'Horizontal Rule', 'miresa' ),
                'link' => esc_html__( 'Link', 'miresa' ),
                'picture' => esc_html__( 'Picture', 'miresa' ),
                'giphy' => esc_html__( 'Giphy', 'miresa' ),
                'video' => esc_html__( 'Video', 'miresa' ),
                'table' => esc_html__( 'Table', 'miresa' ),
                'clear' => esc_html__( 'Remove Font Style', 'miresa' ),
                'misc' => esc_html__( 'Undo-Redo', 'miresa' ),
                'codeview' => esc_html__( 'Code View', 'miresa' ),
                'help' => esc_html__( 'Help', 'miresa' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => array('style','bold','italic','underline','strikethrough','superscript','subscript','fontname','height','forecolor','backcolor','paragraph','emoji','specialchars','list','hr','link','picture','video','table','clear','misc','codeview','help')
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Default Editor Height (px)', 'miresa' ),
            'id'   => 'editor_height',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 200
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Placeholder Text', 'miresa' ),
            'id'   => 'placeholder',
            'type' => 'text',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => ''
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Max. Image File Size (MB)', 'miresa' ),
            'description' => esc_html__( 'The upper limit on the compressed image file size.', 'miresa' ),
            'id'   => 'max_img_size',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'step' => '0.1',
                'autocomplete' => 'off'
            ),
            'default' => 0.2
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Max. Image Width/Height (px)', 'miresa' ),
            'description' => esc_html__( 'The image, if necessary, will be scaled down by ratio to a point that width or height is smaller than this value.', 'miresa' ),
            'id'   => 'max_img_width',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*',
                'autocomplete' => 'off'
            ),
            'default' => 600
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Giphy', 'miresa' ),
            'id'   => 'giphy_title',
            'type' => 'title'
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'API Key (Required)', 'miresa' ),
            'description' => esc_html__( 'You must get a free API key from Giphy to use this feature. For more information, please read the documentation.', 'miresa' ),
            'id'      => 'giphy_api_key',
            'type'    => 'text'
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Language', 'miresa' ),
            'description' => esc_html__( 'The language of the search you are performing.', 'miresa' ),
            'id'   => 'giphy_lang',
            'type' => 'select',
            'options' => array(
                'en' => esc_html__( 'English', 'miresa' ),
                'ge' => esc_html__( 'German', 'miresa' ),
                'it' => esc_html__( 'Italian', 'miresa' ),
                'es' => esc_html__( 'Spanish', 'miresa' ),
                'pt' => esc_html__( 'Portuguese', 'miresa' ),
                'fr' => esc_html__( 'French', 'miresa' ),
                'nl' => esc_html__( 'Dutch', 'miresa' ),
                'ru' => esc_html__( 'Russian', 'miresa' ),
                'pl' => esc_html__( 'Polish', 'miresa' ),
                'ro' => esc_html__( 'Romanian', 'miresa' ),
                'hu' => esc_html__( 'Hungarian', 'miresa' ),
                'da' => esc_html__( 'Danish', 'miresa' ),
                'fi' => esc_html__( 'Finnish', 'miresa' ),
                'sv' => esc_html__( 'Swedish', 'miresa' ),
                'cs' => esc_html__( 'Czech', 'miresa' ),
                'no' => esc_html__( 'Norwegian', 'miresa' ),
                'uk' => esc_html__( 'Ukrainian', 'miresa' ),
                'id' => esc_html__( 'Indonesian', 'miresa' ),
                'he' => esc_html__( 'Hebrew', 'miresa' ),
                'ar' => esc_html__( 'Arabic', 'miresa' ),
                'tr' => esc_html__( 'Turkish', 'miresa' ),
                'ko' => esc_html__( 'Korean', 'miresa' ),
                'th' => esc_html__( 'Thai', 'miresa' ),
                'vi' => esc_html__( 'Vietnamese', 'miresa' ),
                'ja' => esc_html__( 'Japanese', 'miresa' ),
                'zh-CN' => esc_html__( 'Chinese Simplified', 'miresa' ),
                'zh-TW' => esc_html__( 'Chinese Traditional', 'miresa' ),
                'hi' => esc_html__( 'Hindi', 'miresa' ),
                'bn' => esc_html__( 'Bengali', 'miresa' ),
                'fa' => esc_html__( 'Farsi', 'miresa' ),
                'tl' => esc_html__( 'Filipino', 'miresa' ),
                'ms' => esc_html__( 'Malay', 'miresa' )
            ),
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'default' => 'en-US'
        ) );

        $options->add_field( array(
            'name' => esc_html__( 'Pagination', 'miresa' ),
            'description' => esc_html__( 'Max. number of images to show.', 'miresa' ),
            'id'   => 'giphy_pagination',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*'
            ),
            'default' => 10
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Caching (hour)', 'miresa' ),
            'id'      => 'giphy_caching',
            'type' => 'text',
            'attributes' => array(
                'type' => 'number',
                'pattern' => '\d*'
            ),
            'default' => 24
        ) );

        $options->add_field( array(
            'name'    => esc_html__( 'Content Rating', 'miresa' ),
            'id'      => 'giphy_rating',
            'type' => 'select',
            'attributes' => array(
                'autocomplete' => 'off'
            ),
            'options' => array(
                'g' => esc_html__( 'G', 'miresa' ),
                'pg' => esc_html__( 'PG', 'miresa' ),
                'pg-13' => esc_html__( 'PG-13', 'miresa' ),
                'r' => esc_html__( 'R', 'miresa' )
            ),
            'default' => 'g'
        ) );

    }
    /**
    * Colorpicker Labels
    */
    public function colorpicker_labels( $hook ) {
        global $wp_version;
        if( version_compare( $wp_version, '5.4.2' , '>=' ) ) {
            wp_localize_script(
            'wp-color-picker',
            'wpColorPickerL10n',
            array(
                'clear'            => esc_html__( 'Clear', 'miresa' ),
                'clearAriaLabel'   => esc_html__( 'Clear color', 'miresa' ),
                'defaultString'    => esc_html__( 'Default', 'miresa' ),
                'defaultAriaLabel' => esc_html__( 'Select default color', 'miresa' ),
                'pick'             => esc_html__( 'Select Color', 'miresa' ),
                'defaultLabel'     => esc_html__( 'Color value', 'miresa' )
            )
            );
        }
    }

    /**
    * Miresa get option
    */
    static function get_option( $key = '', $default = false ) {
        if ( function_exists( 'cmb2_get_option' ) ) {
            return cmb2_get_option( 'miresa_options', $key, $default );
        }
        $opts = get_option( 'miresa_options', $default );
        $val = $default;
        if ( 'all' == $key ) {
            $val = $opts;
        } elseif ( is_array( $opts ) && array_key_exists( $key, $opts ) && false !== $opts[ $key ] ) {
            $val = $opts[ $key ];
        }
        return $val;
    }

}

/**
 * Returns the main instance of the class.
 */
function MiresaSettings() {  
	return MiresaSettings::instance();
}
// Global for backwards compatibility.
$GLOBALS['MiresaSettings'] = MiresaSettings();