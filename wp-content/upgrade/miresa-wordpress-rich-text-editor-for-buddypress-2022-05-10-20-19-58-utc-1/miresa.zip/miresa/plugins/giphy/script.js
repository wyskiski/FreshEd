/* ANIMATED GIFS */

(function(factory) {
    if (typeof define === 'function' && define.amd) {
      // AMD. Register as an anonymous module.
      define(['jquery'], factory);
    } else if (typeof module === 'object' && module.exports) {
      // Node/CommonJS
      module.exports = factory(require('jquery'));
    } else {
      // Browser globals
      factory(window.jQuery);
    }
  }(function($) {
    $.extend($.summernote.plugins, {
      'giphy': function(context) {
        var self = this;
        var ui = $.summernote.ui;
  
        var $editor = context.layoutInfo.editor;
        var options = context.options;

        context.memo('button.giphy', function() {
          return ui.button({
            contents: miresaParams.gif,
            click: function() {
              self.show();
            },
          }).render();
        });

        this.initialize = function() {
          var $container = options.dialogsInBody ? $(document.body) : $editor;
          var giphy = 'miresa-giphy-' + new Date().getTime();
          var $content = jQuery('<div id="' + giphy +'" class="miresa-giphy" data-offset="0" data-limit="' + miresaParams.limit +'"></div>');
  
          var body = $content[0].outerHTML;
  
          this.$dialog = ui.dialog({
            title: miresaParams.insertgif,
            className: 'miresa-giphy-dialog',
            body: body,
          }).render().appendTo($container);

          var data = {
            'action': 'miresaGiphyTrending',
            'nonce': miresaParams.nonce
          };

          jQuery.ajax({
              url : miresaParams.ajaxurl,
              data : data,
              type : 'POST',
              beforeSend: function ( xhr ) {
                  jQuery('#' + giphy).find('.miresa-msg').remove();
              },
              success: function(data){
                  if(data) {
                    jQuery('#' + giphy).append(data);
                  } else {
                      var $msg = jQuery('<div class="miresa-msg danger">' + miresaParams.wrong + '</div>');
                      jQuery('#' + giphy).html($msg);
                  }
              },
              error: function(jqXHR,error, errorThrown) {
                  var $msg = jQuery('<div class="miresa-msg danger"></div>');
                  if(jqXHR.status&&jqXHR.status==400){
                      $msg.append(jqXHR.responseText);
                  }else{
                      $msg.append(miresaParams.wrong);
                  }
                  jQuery('#' + giphy).html($msg);
              }
          });

        };

        this.show = function() {
            var text = context.invoke('editor.getSelectedText');
            context.invoke('editor.saveRange');
            this.showGiphyDialog(text).then(function(selectChar) {
              context.invoke('editor.restoreRange');
    
              // build node
              var $node = $('<span></span>').html(selectChar)[0];
    
              if ($node) {
                // insert video node
                context.invoke('editor.insertNode', $node);
              }
            }).fail(function() {
              context.invoke('editor.restoreRange');
            });
          };

          /**
         * show image dialog
         *
         * @param {jQuery} $dialog
         * @return {Promise}
         */
        this.showGiphyDialog = function(text) {
            return $.Deferred(function(deferred) {
              var $giphyDialog = self.$dialog;
              var $giphyNode = $giphyDialog.find('.miresa-giphy');
    
              ui.onDialogShown(self.$dialog, function() {
                $giphyNode.on('click','.miresa-grid-item > img', function(event) {
                  event.preventDefault();
                  deferred.resolve('<img class="miresa-gif" src="' + $(event.currentTarget).attr('data-img') + '" alt="' + $(event.currentTarget).attr('data-title') + '" />');
                  ui.hideDialog(self.$dialog);
                });
              });
    
              ui.onDialogHidden(self.$dialog, function() {
                $giphyNode.off('click');
                if (deferred.state() === 'pending') {
                  deferred.reject();
                }
              });
    
              ui.showDialog(self.$dialog);
            });
          };

      },
    });
  }));

/* Search Submit */
(function($) {
    "use strict";
    $('body').on('click','.miresa-search-box button.note-btn',function(){
      var wrapper = $(this).closest('div.miresa-giphy');
      var keyword = wrapper.find('.miresa-search-box > input.note-input').val();
      var data = {
        'action': 'miresaGiphySearch',
        'nonce': miresaParams.nonce,
        'keyword': keyword,
        'offset': 0,
        'loadmore': 'no'
      };
      $.ajax({
        url : miresaParams.ajaxurl,
        data : data,
        type : 'POST',
        beforeSend: function ( xhr ) {
          wrapper.find('.miresa-msg').remove();
          wrapper.css('opacity', 0.5);
          wrapper.css('pointer-events', 'none');
        },
        success: function(data){
            if(data) {
              wrapper.html(data);
            } else {
                var $msg = $('<div class="miresa-msg danger">' + miresaParams.wrong + '</div>');
                wrapper.html($msg);
            }
        },
        error: function(jqXHR,error, errorThrown) {
            var $msg = $('<div class="miresa-msg danger"></div>');
            if(jqXHR.status&&jqXHR.status==400){
                $msg.append(jqXHR.responseText);
            }else{
                $msg.append(miresaParams.wrong);
            }
            wrapper.html($msg);
        }
      }).done(function( response ) {
        wrapper.css('opacity', 1);
        wrapper.css('pointer-events', 'auto');
    });
  });

  /* Load More */
  $('body').on('click','.miresa-loadmore button.note-btn',function(){
    var wrapper = $(this).closest('div.miresa-giphy');
    var keyword = wrapper.find('.miresa-search-box > input.note-input').data('keyword');
    var offset = wrapper.data('offset');
    var limit = wrapper.data('limit');
    var newOffset = parseInt(offset) + parseInt(limit);

    var data = {
      'action': 'miresaGiphySearch',
      'nonce': miresaParams.nonce,
      'keyword': keyword,
      'offset': newOffset,
      'loadmore': 'yes'
    };
    $.ajax({
      url : miresaParams.ajaxurl,
      data : data,
      type : 'POST',
      beforeSend: function ( xhr ) {
        wrapper.find('.miresa-msg').remove();
        wrapper.css('opacity', 0.5);
        wrapper.css('pointer-events', 'none');
      },
      success: function(data){
          if(data) {
            wrapper.find('.miresa-grid').append(data);
          } else {
              var $msg = $('<div class="miresa-msg danger">' + miresaParams.wrong + '</div>');
              wrapper.html($msg);
          }
      },
      error: function(jqXHR,error, errorThrown) {
          var $msg = $('<div class="miresa-msg danger"></div>');
          if(jqXHR.status&&jqXHR.status==400){
              $msg.html(jqXHR.responseText);
          }else{
              $msg.html(miresaParams.wrong);
          }
          wrapper.html($msg);
      }
    }).done(function( response ) {
      wrapper.css('opacity', 1);
      wrapper.css('pointer-events', 'auto');
  });

  wrapper.data('offset', newOffset);
});
})(jQuery);

/* STICKERS */

(function(factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['jquery'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // Node/CommonJS
    module.exports = factory(require('jquery'));
  } else {
    // Browser globals
    factory(window.jQuery);
  }
}(function($) {
  $.extend($.summernote.plugins, {
    'giphyStickers': function(context) {
      var self = this;
      var ui = $.summernote.ui;

      var $editor = context.layoutInfo.editor;
      var options = context.options;

      context.memo('button.giphyStickers', function() {
        return ui.button({
          contents: miresaParams.sticker,
          click: function() {
            self.show();
          },
        }).render();
      });

      this.initialize = function() {
        var $container = options.dialogsInBody ? $(document.body) : $editor;
        var giphy = 'miresa-giphy-' + new Date().getTime();
        var $content = jQuery('<div id="' + giphy +'" class="miresa-giphy-stickers" data-offset="0" data-limit="' + miresaParams.limit +'"></div>');

        var body = $content[0].outerHTML;

        this.$dialog = ui.dialog({
          title: miresaParams.insertsticker,
          className: 'miresa-giphy-stickers-dialog',
          body: body,
        }).render().appendTo($container);

        var data = {
          'action': 'miresaGiphyStickersTrending',
          'nonce': miresaParams.nonce
        };

        jQuery.ajax({
            url : miresaParams.ajaxurl,
            data : data,
            type : 'POST',
            beforeSend: function ( xhr ) {
                jQuery('#' + giphy).find('.miresa-msg').remove();
            },
            success: function(data){
                if(data) {
                  jQuery('#' + giphy).append(data);
                } else {
                    var $msg = jQuery('<div class="miresa-msg danger">' + miresaParams.wrong + '</div>');
                    jQuery('#' + giphy).html($msg);
                }
            },
            error: function(jqXHR,error, errorThrown) {
                var $msg = jQuery('<div class="miresa-msg danger"></div>');
                if(jqXHR.status&&jqXHR.status==400){
                    $msg.append(jqXHR.responseText);
                }else{
                    $msg.append(miresaParams.wrong);
                }
                jQuery('#' + giphy).html($msg);
            }
        });

      };

      this.show = function() {
          var text = context.invoke('editor.getSelectedText');
          context.invoke('editor.saveRange');
          this.showGiphyDialog(text).then(function(selectChar) {
            context.invoke('editor.restoreRange');
  
            // build node
            var $node = $('<span></span>').html(selectChar)[0];
  
            if ($node) {
              // insert video node
              context.invoke('editor.insertNode', $node);
            }
          }).fail(function() {
            context.invoke('editor.restoreRange');
          });
        };

        /**
       * show image dialog
       *
       * @param {jQuery} $dialog
       * @return {Promise}
       */
      this.showGiphyDialog = function(text) {
          return $.Deferred(function(deferred) {
            var $giphyDialog = self.$dialog;
            var $giphyNode = $giphyDialog.find('.miresa-giphy-stickers');
  
            ui.onDialogShown(self.$dialog, function() {
              $giphyNode.on('click','.miresa-grid-item > img', function(event) {
                event.preventDefault();
                deferred.resolve('<img class="miresa-gif" src="' + $(event.currentTarget).attr('data-img') + '" alt="' + $(event.currentTarget).attr('data-title') + '" />');
                ui.hideDialog(self.$dialog);
              });
            });
  
            ui.onDialogHidden(self.$dialog, function() {
              $giphyNode.off('click');
              if (deferred.state() === 'pending') {
                deferred.reject();
              }
            });
  
            ui.showDialog(self.$dialog);
          });
        };

    },
  });
}));

/* Search Submit */
(function($) {
  "use strict";
  $('body').on('click','.miresa-search-box button.note-btn',function(){
    var wrapper = $(this).closest('div.miresa-giphy-stickers');
    var keyword = wrapper.find('.miresa-search-box > input.note-input').val();
    var data = {
      'action': 'miresaGiphyStickersSearch',
      'nonce': miresaParams.nonce,
      'keyword': keyword,
      'offset': 0,
      'loadmore': 'no'
    };
    $.ajax({
      url : miresaParams.ajaxurl,
      data : data,
      type : 'POST',
      beforeSend: function ( xhr ) {
        wrapper.find('.miresa-msg').remove();
        wrapper.css('opacity', 0.5);
        wrapper.css('pointer-events', 'none');
      },
      success: function(data){
          if(data) {
            wrapper.html(data);
          } else {
              var $msg = $('<div class="miresa-msg danger">' + miresaParams.wrong + '</div>');
              wrapper.html($msg);
          }
      },
      error: function(jqXHR,error, errorThrown) {
          var $msg = $('<div class="miresa-msg danger"></div>');
          if(jqXHR.status&&jqXHR.status==400){
              $msg.append(jqXHR.responseText);
          }else{
              $msg.append(miresaParams.wrong);
          }
          wrapper.html($msg);
      }
    }).done(function( response ) {
      wrapper.css('opacity', 1);
      wrapper.css('pointer-events', 'auto');
  });
});

/* Load More */
$('body').on('click','.miresa-loadmore button.note-btn',function(){
  var wrapper = $(this).closest('div.miresa-giphy-stickers');
  var keyword = wrapper.find('.miresa-search-box > input.note-input').data('keyword');
  var offset = wrapper.data('offset');
  var limit = wrapper.data('limit');
  var newOffset = parseInt(offset) + parseInt(limit);

  var data = {
    'action': 'miresaGiphyStickersSearch',
    'nonce': miresaParams.nonce,
    'keyword': keyword,
    'offset': newOffset,
    'loadmore': 'yes'
  };
  $.ajax({
    url : miresaParams.ajaxurl,
    data : data,
    type : 'POST',
    beforeSend: function ( xhr ) {
      wrapper.find('.miresa-msg').remove();
      wrapper.css('opacity', 0.5);
      wrapper.css('pointer-events', 'none');
    },
    success: function(data){
        if(data) {
          wrapper.find('.miresa-grid').append(data);
        } else {
            var $msg = $('<div class="miresa-msg danger">' + miresaParams.wrong + '</div>');
            wrapper.html($msg);
        }
    },
    error: function(jqXHR,error, errorThrown) {
        var $msg = $('<div class="miresa-msg danger"></div>');
        if(jqXHR.status&&jqXHR.status==400){
            $msg.html(jqXHR.responseText);
        }else{
            $msg.html(miresaParams.wrong);
        }
        wrapper.html($msg);
    }
  }).done(function( response ) {
    wrapper.css('opacity', 1);
    wrapper.css('pointer-events', 'auto');
});

wrapper.data('offset', newOffset);
});
})(jQuery);